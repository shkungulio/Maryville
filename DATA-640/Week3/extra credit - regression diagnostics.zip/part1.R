# (C) 2020, Christopher Shannon

# Code for part 1

# Introduction - output from summary of a
# linear model (Least Squares Regression)
# can be misleading.

data("anscombe")
View(anscombe)

# plot Anscombe's quartet
par(mfrow=c(2,2)) # plot four sub-screens in one screen
fit <- list()
for (i in 1:4) {
  a.title <- paste("y",i," on  x",i,sep="")
  a.xlab  <- paste("x", i, sep="")
  a.ylab  <- paste("y", i, sep="")
  plot(anscombe[,c(i,i + 4)], xlim=c(4,20), ylim=c(3,13),
       xlab=a.xlab, ylab=a.ylab, main=a.title)
  f <- formula(paste("y",i," ~ x",i,sep=""))
  fit[[i]] <- lm(f, data=anscombe)
  abline(fit[[i]], col="red")
}
par(mfrow=c(1,1)) # restore one screen per plot

summary(fit[[1]])
summary(fit[[3]])

summary(fit[[2]])
summary(fit[[4]])

# Method for detecting whether a model is properly
# fitted is to look at the residuals versus fitted
# values.

set.seed(122)

x1   <- runif(50, 0.5, 2)
x1sq <- x1^2
e    <- rnorm(50, 2, 0.2)
y  <- x1 + x1sq + e

# regression equation is y = x1 + x2^2 + e
# The relationship is quadratic

fit2 <- lm(y ~ x1) # But we leave out x1sq
summary(fit2)

# But, look at the plots
par(mfrow=c(1,2))
plot(fit2, which=c(1,3))

# Residuals vs. fitted shows a pattern.
# Probably missing a variable.
fit3 <- lm(y ~ x1 + x1sq)
plot(fit3, which=c(1,3))

summary(fit3)


#####################################
# Demo of the Central Limit Theorem

# Describe a Uniform distribution.

par(mfrow=c(2,1))
hist((1:20)/20, breaks=(0:20)/20, probability=T, 
     ylim=c(0,1.6), xlab="X, for N=20", ylab="Y", 
     main="Uniform(0,1) Distribution", col="lavender")
text(0.5, 1.5, expression(
  paste("E(X) = (H - L)/2 = 0.5; Var(X) =", 
        (H - L)^2/12, "= 1/12")))
text(0.5, 1.2, paste("P(X < 0.25) = 0.25;",
                     "P(X > 0.7) = 1 - P(X < 0.7) = 0.3, etc."))

# Get random variables from a uniform(0,1) distribution.

set.seed(101)
udist <- runif(1e6, 0, 1) # 1e6 = 10e5 = 100000, got it?
umeans <- c(x.bar=mean(udist),mu=1/2)
uvars  <- c(samp.var=var(udist),sigma=1/12)

hist(udist, breaks=20, xlab="X, N = 100,000; breaks = 100",
     main="Histogram of random values from Uniform(0,1)",
     ylim=c(0,2), probability=T, col="beige")
text(0.5,1.6, paste("Sample mean =", round(umeans[1],4), 
                    "  True mean =", umeans[2], "\n",
                    "Sample var =", round(uvars[1],4), 
                    "  True var =", round(1/12, 4)))
par(mfrow=c(1,1))

# mc.sim(dist, mu, sigma2, n, m=1000, breaks=100, returnval=F)
#
# Runs a Monte Carlo simulation of the normalized means of
# a sample from a probability distribution. The purpose
# of this function is to run simulations that demonstrate
# the Central Limit Theorem's property that the normalized
# means of any distribution, if the mean and variance exist
# and are finite, converge to a standard normal distribution
# as the sample size n increases toward infinity.
#
# Parameters:
#
# dist:   The distrubtion you want to normalize.
#         This should be a numeric vector.
# mu:     The expected value of the distribution.
# sigma2: The variance of the distribution.
# n:      Number of random samples from the distribution
#         for each iteration of the simulation.
# m:      Number of iterations for the Monte Carlo
#         simulation. Default is 1000
# breaks: Number of breaks to compute for the histogram.
#         Default is 100.
# returnval:  Tells function to return the normalized
#             means from the simulation.
mc.sim <- function(dist, mu, sigma2, n, m=1000, 
                   breaks=100, returnval=F) {
  Z <- c()
  for (i in 1:m) {
    # Get sample from distribution.
    S <- dist[sample(1:length(dist), n)]
    
    # Transforms our means to a
    # standard normal distribution.
    Z[i] <- sqrt(n)*(mean(S) - mu)/sqrt(sigma2)
  }
  
  # Display our results
  hist(Z, probability=T, col="beige", breaks=breaks,
       main=paste("Histogram of normalized sample mean\n",
                  "for sample size n = ", n, sep=""))
  
  # return the transformed sampled means if required.
  if (returnval) Z
}

set.seed(101)
# Take random sample of size 100000
# from a Uniform(0,1) distribution.
udist <- runif(1e6, 0, 1) # 1e6 = 100000

# run for n = 1, use 100000 iterations 
# for each Monte Carlo simulation.
par(mfrow=c(3,1))
mc.sim(udist, 1/2, 1/12, 1, 100000)
mc.sim(udist, 1/2, 1/12, 2, 100000)
mc.sim(udist, 1/2, 1/12, 3, 100000)
par(mfrow=c(2,1))
mc.sim(udist, 1/2, 1/12, 5, 100000)
mc.sim(udist, 1/2, 1/12, 10, 100000)
par(mfrow=c(1,1))
# (C) Christopher Shannon, 2020

##################################
# Leverage points, Huber Data Set

huber <- read.table("huber.txt", header=T)

par(mfrow=c(1,1))
fit.huber.good <- lm(YGood ~ x, data=huber)

par(mfrow=c(1,2))
plot(huber[-6,"x"], huber[-6,"YGood"],
     xlab="x", ylab="Y Good", 
     xlim=range(huber$x), ylim=range(huber$YGood),
     main="\"Good\" Leverage Point")
points(huber[6,c(1,3)],pch=21, bg="green", cex=1.5)
abline(fit.huber.good, col="blue", lty=2)

fit.huber.bad <- lm(YBad ~ x, data=huber)
plot(huber[-6,"x"], huber[-6,"YBad"],
     xlab="x", ylab="Y Bad", 
     xlim=range(huber$x), ylim=range(huber$YGood),
     main="\"Bad\" Leverage Point")
points(huber[6,c(1,2)],pch=21, bg="red", cex=1.5)
abline(fit.huber.bad, col="blue", lty=2)


# @@@@@@@@@@
# What is the (Hat) Matrix?

huber <- read.table("huber.txt", header=T)

(X <- model.matrix(~ x, data=huber))
(XTX <- t(X)%*%X)         # Gives us X'X
(XTX.inv <- solve(XTX))   # Inverts X'X = 1/(X'X)
H <- X%*%XTX.inv%*%t(X)   # Gives us the hat matrix H
(round(H,3)) # Displaying the Hat Matrix

# Properties of the Hat Matrix
(round(H%*%H,3))   # H multiplied by itself is itself! HH = H
# In other words, H is "idempotent".

(fit.huber.good <- lm(YGood ~ x, data=huber))$coefficients
(fit.huber.bad <- lm(YBad ~ x, data=huber))$coefficients

(hatvalues(fit.huber.good))
(hatvalues(fit.huber.bad))

# average(hatvalues) are always equal to 2/n.
(avg.hat <- mean(hatvalues(fit.huber.good)))
(c(avg.hat=avg.hat, TwoOverN=2/nrow(huber)))

# Cut-off value for leverage = 2 X average(hatvalues)
(leverage.cutoff <- 2*2/nrow(huber))

# Any values above 0.6666667?
(hatvalues(fit.huber.bad))
(hatvalues(fit.huber.bad) > 2*2/nrow(huber))

# You can then use this to look at the values
# in your data are leverage points.
(huber[hatvalues(fit.huber.bad) > 2*2/nrow(huber),])

# Now, what measure do you use to tell
# the difference between good and bad leverage points?
# You use what are called standardized residuals.
# A standardized residual is the number of
# standard deviations your error term is
# FROM THE FITTED MODEL (i.e. regression line).

round(std.resids.good <- 
        rstandard(fit.huber.good), 3)
round(std.resids.bad  <- 
        rstandard(fit.huber.bad), 3)

data.frame(good.resids=std.resids.good, 
           bad.resids=std.resids.bad,
           hatvalues=hatvalues(fit.huber.good))


par(mfrow=c(1,2))
plot(huber[-6,"x"], huber[-6,"YGood"],
     xlab="x", ylab="Y Good", 
     xlim=range(huber$x), ylim=range(huber$YGood),
     main="\"Good\" Leverage Point")
points(huber[6,c(1,3)],pch=21, bg="green", cex=1.5)
abline(fit.huber.good, col="blue", lty=2)
text(8,-10.3, cex=1, col="blue", pos=2,
     labels=
       paste("Std. Residual = ",round(std.resids.good[6],3),sep="")
)
text(8,-11.3, cex=1, col="black", pos=2,
     labels=
       paste("Leverage = ",
             round(hatvalues(fit.huber.good)[6],3), sep="")
)

plot(huber[-6,"x"], huber[-6,"YBad"],
     xlab="x", ylab="Y Bad", 
     xlim=range(huber$x), ylim=range(huber$YGood),
     main="\"Bad\" Leverage Point")
points(huber[6,c(1,2)],pch=21, bg="red", cex=1.5)
abline(fit.huber.bad, col="red", lty=2)
text(10,2.1, cex=1, col="red", pos=2,
     labels=
       paste("Std. Residual = ",round(std.resids.bad[6],3),sep="")
)
text(10,1.1, cex=1, col="black", pos=2,
     labels=
       paste("Leverage = ",
             round(hatvalues(fit.huber.bad)[6],3), sep=""))

par(mfrow=c(1,1))

# Cutoff values for small and medium data sets
# are less than -2 and greater than 2 standard
# deviations. For large data sets, your cutoff
# values are less than -4 and greater than 4
# standard deviations.

# Strategies for dealing with leverage points.
# 1) consider whether the leverage points
#    belong in the data--especially if it's
#    a leverage point that is also an
#    outlier (bad leverage point).
#
# 2) Consider fitting a different model.
#    The leverage point may exist because
#    the model is mis-specified.
#
#    In the Huber data set, adding an
#    x-squared term appears to better
#    fit the data.

fit.huber.better <- lm(YBad ~ x + I(x^2),
                       data=huber)
summary(fit.huber.better)

(hatvalues(fit.huber.better))
c(lvg.cutoff=2*(2+1)/nrow(huber))
(rstandard(fit.huber.better))

huber.yrange <- range(huber$YBad)*2 # Stretch the range
huber.xrange <- range(huber$x)*1.2  # Stretch the range

par(mfrow=c(2,1)) # Plot YBad vs. x for original 
# and alternative models.

# Original model for YBad vs. x
plot(huber[,c("x","YBad")], ylim=huber.yrange,
     main="Original Model for Huber YBad vs. x")
abline(fit.huber.bad, lty=2, col="red")
text(3,4,
     expression(
       paste("YBad ~ 0.068 - 0.081x")),
     col="blue")
text(3,2.5,
     expression(
       paste(R^2," = 0.082")), col="blue")

# Original model for YBad vs. x
plot(huber[,c("x","YBad")], ylim=huber.yrange,
     main="Alternative Model for Huber YBad vs. x")
huber.pred.x <- seq(huber.xrange[1],huber.xrange[2], by=0.1)
points(huber.pred.x, predict(fit.huber.better,
                             data.frame(x=huber.pred.x)),
       type="l", col="red", lty=2)
text(3,4,expression(
  paste("YBad ~ -1.741 - 0.659x + 0.083", 
        x^2,sep="")), col="blue")
text(3,2.5,
     expression(
       paste(R^2," = 0.952",
             sep="")), col="blue")

par(mfrow=c(1,1))


######################################
# Zagat: NYC Restaurant Survey, 2001 #
######################################

# Now that we understand what standardized residuals
# are and their role in identifying outliers and
# non-random patterns in our error term, we can
# look at the default plots for lm (the linear model)

# Sheather - NYC Restaurant data set.
nyc <- read.csv("nyc.csv", head=T, row.names=2)
nyc <- nyc[,-1] # remove ID field.

summary(nyc)
par(mfrow=c(2,1))
boxplot(nyc$Price, xlab="Price", col="aquamarine",
        main="Response", horizontal=T)
boxplot(nyc[,c(-1,-5)], xlab="Survey Scale",
        col=heat.colors(4),
        main="Continuous Predictors", horizontal=T)
par(mfrow=c(1,1))
nyc.east.prop <- sum(nyc$East)/nrow(nyc)
pie(
  c(1 - nyc.east.prop, nyc.east.prop),
  c(
    paste("West: ", round((1 - nyc.east.prop)*100,1),"%",sep=""),
    paste("East: ", round((    nyc.east.prop)*100,1),"%",sep="")
  ), 
  main="Categorical Predictor")

# For now we won't convert East to a factor.

# Look at the response and continuous predictors
pairs(nyc[, 1:4]) # column 5 is the categorical var.

# Sheather - NYC Restaurant data set.
nyc <- read.csv("nyc.csv", head=T, row.names=2)
nyc <- nyc[,-1] # remove ID field.

fit.nyc <- lm(Price ~ Food + Decor + Service + East,
              data=nyc)

# So, let's check our leverages to identify
# influential data points.
nyc.hat <- hatvalues(fit.nyc)

# leverage cutoff value: 2*(p + 1)/n
nrow(nyc) # 168 observations
(nyc.levcutoff <- 2*(4 + 1)/168) # 0.05952381

(nyc.levg <- which(nyc.hat > nyc.levcutoff))

# Let's look at the plots with these
# points highlighted.

# Gives different color to certain points.
nyc.color <- rep("black", nrow(nyc))
nyc.color[nyc.levg] <- "blue" # for outline color
nyc.bg <- nyc.color # use same values for fill

# See ?points for how values map to symbols
# Vector of symbols to use.
nyc.pch   <- rep(1, nrow(nyc))
nyc.pch[nyc.levg]   <- 24 # a filled triangle

# Controls the magnification of the point size.
# Use this to diminish or increase the size of
# a point on a point-by-point or default basis.
nyc.cex   <- rep(1, nrow(nyc)) # 1 is default
nyc.cex[nyc.levg] <- 1.2 # make a little bigger

# Plot index numbers only for the leverages.
nyc.labels <- rep("", nrow(nyc)) # set zero-length labels
nyc.labels[nyc.levg] <- 
  nyc.levg # set index numbers as labels

# Now, plot the darned thing!
plot(fit.nyc, id.n = nrow(nyc), # print all labels
     labels.id=nyc.labels, # only 4 labels will show
     col=nyc.color, bg=nyc.color, 
     pch=nyc.pch, cex=nyc.cex)

# At this point, we are very concerned about
# obseration number 130. The other leverages
# are so-called "good" leverage points. But
# because they are also unusually influential,
# we should inquire about them, too.
#
# What we need to do now is make a decision
# as to whether these points should be in our
# model.
nyc.levg
nyc[nyc.levg,]

# Obs 130 is the Rainbow Grill. According to
# the Zagat 2001 survey (page 154),
#
#   After surviving a "union fiasco", these Cipriani-run 
#   Rock Center Italian siblings are back with their 
#   ever-"spectacular views".
#
# That explains the low score in service versus
# it's other high scores in other areas. So, we
# will keep this in the model.
#
# https://books.google.co.in/books?id=V0UsAQAAMAAJ&dq=zagat+2001+new+york+city&focus=searchwithinvolume&q=%22rainbow+grill%22
#
# Obs 115: Lamarca is described in the same guide as:
# "Too often overlooked."
# 
# Obs 117: Veronica achieves a high food score despite
# having low service and decor scores.
#
# Obs 168: Also despite low decor and service scores,
# Gennaro achieves a very high food score for
# a competitive price. The 2008 Zagat Guide for NYC
# restaurants describes it as follows:
#
# Upper Westsiders generally gush over this
# "unassuming" cash-only Italian "gem",
# citing "sophisticated" preparations at
# "bargain" prices; to cope with "awful lines",
# "crapshoot" service and a room "packed
# tighter than a box of pasta", go at off-hours.

# Qtd. in Sheather 2009, pg 166.



############################################################
# Cook's Distance: Measuring Influence of a Leverage Point #
############################################################

# One thing to note is that points that are not
# considered leverage points may still be influential.
# In order to test this, we use Cook's Distance to
# measure the influence of a single point on the
# the model.
#
# Cook's Distance of any single point (observation) is
# defined as the sum of the differences between
# the expected value of y_i (y-hat_i) when 

# We will look at sample data from the Coleman Report (1966),
# as analyzed by Mosteller and Tukey (1977). The fields are:
#
# salaryP     Salaries per pupil in school
# fatherWc    Percentage of white-collar fathers
# sstatus     Social status (see ?coleman)
# teacherSc   Mean teacher's verbal test score
# motherLev   mean mother's educational level, one unit
#             is equal to 2 school years.
# Y           verbal mean test score (y, of all 6th graders)

# install.packages("robustbase")
library(robustbase)
data(coleman)
?coleman

summary(coleman)

par(mfrow=c(2,3))
for (i in c(6,1:5)) {boxplot(coleman[,i], col="lavender", 
                             horizontal=T, main=names(coleman)[i])}
par(mfrow=c(1,1))

panel.cor <- function(x, y, digits = 2, prefix = "", cex.cor, ...)
{
  usr <- par("usr"); on.exit(par(usr))
  par(usr = c(0, 1, 0, 1))
  r <- abs(cor(x, y))
  txt <- format(c(r, 0.123456789), digits = digits)[1]
  txt <- paste0(prefix, txt)
  if(missing(cex.cor)) cex.cor <- 0.8/strwidth(txt)
  text(0.5, 0.5, txt, cex = cex.cor * r)
}

pairs(coleman[,c(6,1:5)], 
      upper.panel=panel.smooth,
      lower.panel = panel.cor)


fit.coleman <- lm(Y ~ salaryP + fatherWc + sstatus +
                    teacherSc + motherLev, data=coleman)
summary(fit.coleman)

# Plot regression diagnostic plots
par(mfrow=c(2,2)) # plot 4 sub-panels.
plot(fit.coleman)
par(mfrow=c(1,1)) # reset graphic device to a single panel.

# Plots only Residuals vs Leverage
plot(fit.coleman, which=5)

######################
# Effect of removing an influential data point
#

fit.coleman.no18 <- 
  lm(Y ~ salaryP + fatherWc + sstatus +
       teacherSc + motherLev, data=coleman[-18,])

fit.coleman.no13_18 <- 
  lm(Y ~ salaryP + fatherWc + sstatus +
       teacherSc + motherLev, data=coleman[c(-3, -18),])

# We remove observation 18 from the dataset.
summary(fit.coleman.no18)

# Regression model without any points removed.
summary(fit.coleman)

# Looking at the summary, we can see that
# removing this point has a dramatic effect on
# the model. Now, almost all the regression 
# coefficients are significant.

# Now, let's form Cook's Distance for this
# one point.
yhat.coleman    <- fitted.values(fit.coleman)
yhat.coleman.18 <- predict(fit.coleman.no18, coleman)
MSE.coleman    <- summary(fit.coleman)$sigma^2

coleman.cookd.18 <- 
  sum((yhat.coleman - yhat.coleman.18)^2)/
  ((5 + 1) * MSE.coleman)
coleman.cookd.18

# Let's also do this using the alternative
# formula, using leverages (computationally much easier)
hat.coleman <- hatvalues(fit.coleman)
residsq.coleman <- residuals(fit.coleman)^2 # our e-hat-squared
coleman.cookd.18.alt <- 
  (residsq.coleman[18]/((5 + 1)*MSE.coleman))*
  (hat.coleman[18]/(1 - hat.coleman[18])^2)

data.frame(cookd.18=coleman.cookd.18, 
           cookd.18.alt=coleman.cookd.18.alt)

# The easy way (much more user friendly)
coleman.cookd.all <- cooks.distance(fit.coleman)
coleman.cookd.all[18]

# Some inference with Cook's D.
# How much is too much? Cook's Distance
# is related to the F-distribution, where
# Cook's D corresponds to the percentile
# on an F(p, n - p). If the percentile
# is less than 10% or 20%, then the point
# is not considered influential. If it
# approaches 50%, then the point is
# significantly influential and should
# be considered for remedial measures,
# like removal or fitting a different
# model.

round(pf(coleman.cookd.all[18], 6, 20 - 6)*100,1)

# 0.341037
# This is the 34th percentile, so it is influential.
# It's borderline serious.

# Let's look at the coleman case 18 to see 
# what it looks like.
coleman[18,]
summary(coleman)

# Let's look at the rest of the coleman
# cases with leverages, standardized residuals
# and Cook's distance.
coleman.diag <- data.frame(coleman,
                           levrg=round(hatvalues(fit.coleman),3),
                           stdres=round(rstandard(fit.coleman),3),
                           cookD=round(cooks.distance(fit.coleman),3),
                           Fpct=
                             round(
                               pf(cooks.distance(fit.coleman),6, 20 - 6)*100,
                               1))

coleman.diag

# Let's see what the Residuals vs Leverage points look
# like with point 18 removed.
plot(fit.coleman.no18, which=5, main="Point 18 removed.")

# Now, point 3 looks like it might be a problem.
# Let's look at point 3 in the data.

# Get Cook's Distances for the regression equation.
cooks.coleman <- cooks.distance(fit.coleman)

# View cook's distances
round(cooks.coleman, 3)

# Cook's Distances are distributed according to the
# F-distribution with m degrees of freedom for the numerator
# equal to the number of variables (including intercept)
# in the model. And the denominator n degrees of freedom are
# equal to the number of observations minus m. Use the
# distribution function pf() to estimate which quantile 
# that each point is at.
cooks.fdist   <- pf(cooks.coleman, 6, 14)
round(cooks.fdist, 3)

# Let's see what point 18 looks like, along with 3 of the next highest
# Cook's Distances. We will also include standardized residusals and leverage.
std.res <- rstandard(fit.coleman)
lvg     <- hatvalues(fit.coleman)
cd <- data.frame(coleman,lvg=lvg, std.res=std.res, 
                 cooks.d=cooks.coleman, F.pct=cooks.fdist)
round(cd[cd$F.pct > 0.005,], 3)

# Let's calculate the quantile for Cook's Distance
# at point #3.  Note the quotes around "3". This
# refers to the row by its row name, not by its
# index in the data set. This gives us Cook's
# Distance for the single point.
cooks.distance(fit.coleman.no18)["3"] # 0.2304579

# Number of variables has not changed, but
# the number of observations has. So, instead of
# 20 observations, we now have 19. So, the numerator
# and denominator degrees of freedom for the F-percentile
# function need to be 6 and 19 - 6 = 13: 6 and 13.
pf(cooks.distance(fit.coleman.no18)["3"], 6, 13)

# But point 3 is still an outlier. Its standardized
# residual is almost -3 standard deviations from
# the fitted model. So we may still be justified
# in identifying it as a candidate for removal.
# But always confirm with subject-matter experts.
rstandard(fit.coleman.no18)["3"]

plot(fit.coleman.no18, which=5,
     pch=c(1,1,24,rep(1,16)),
     cex=c(1,1,1.5,rep(1,16)),
     bg=c("black","black","blue",rep("black",16)))